package com.example.pj_lab11;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

import Adapter.MinatureAdapter;
import Model.Minature;

public class MainActivity extends AppCompatActivity {

    RecyclerView recyclerView;
    MinatureAdapter minatureAdapter;
    List<Minature> minatureList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        // Initialize the product list
        minatureList = new ArrayList<>();
        minatureList.add(new Minature("Grey Knights Kaldor Draigo", "miniature", 3273, "https://preview.redd.it/kaldor-draigo-kitbash-concept-v0-d8ui221isiqa1.jpg?auto=webp&s=f218d8908ae5b49248fea95c98c4b479283a7acb"));
        minatureList.add(new Minature("Grey Knights Brother Captain", "miniature", 1500, "https://legendarywargame.com/tmp/shop_product/2019/09/25/1569406922.webp"));

        minatureAdapter = new MinatureAdapter(this, minatureList);
        recyclerView.setAdapter(minatureAdapter);
    }
}